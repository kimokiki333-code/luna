"""World Intelligence live dashboard."""
