"""Post-task result emission, memory work, reflections, and review context."""

from __future__ import annotations

import contextvars
import json
import copy
import functools
import logging
import pathlib
import threading
import time
from dataclasses import replace
from typing import Any, Callable, Dict, List

from ouroboros.settings_integrity import copy_task_settings_context
from ouroboros.cost_projection import cost_projection, resolve_cost_pair
from ouroboros.task_results import (
    STATUS_COMPLETED,
    STATUS_FAILED,
    load_task_result,
    write_task_result,
)
from ouroboros.artifacts import collect_task_artifact_records, merge_artifact_records
from ouroboros.outcomes import (
    EXECUTION_BEST_EFFORT,
    EXECUTION_FAILED,
    EXECUTION_INFRA_FAILED,
    EXECUTION_OK,
    BEST_EFFORT_REASON_CODES,
    apply_receipt_absent_flag,
    artifact_bundle_from_result,
    build_verification_ledger,
    custody_debt_axes,
    derive_loop_outcome,
    maybe_write_verification_artifact,
    normalize_outcome_axes,
)
from ouroboros.outcome_receipt_store import task_verification_receipts
from ouroboros.contracts.task_contract import build_task_contract
from ouroboros.subagents import envelope_from_task, substrate_result_fields
from ouroboros.subagent_messages import initiator_meta, subagent_message_meta
from ouroboros.utils import utc_now_iso, append_jsonl, truncate_review_artifact as _truncate_with_notice
from ouroboros.utils import in_worker_process
from ouroboros.post_task_checkpoint import (
    LatePhaseRun,
    POST_TASK_SYNTHESIS_INFLIGHT as _POST_TASK_SYNTHESIS_INFLIGHT,
    POST_TASK_SYNTHESIS_LOCK as _POST_TASK_SYNTHESIS_LOCK,
    bind_late_phase_run,
    is_root_post_task as _is_root_post_task,
    post_task_synthesis_is_open as _post_task_synthesis_is_open,
    post_task_synthesis_is_terminal as _post_task_synthesis_is_terminal,
    root_checkpoint_roots as _root_checkpoint_roots,
    root_post_task_already_completed as _root_post_task_already_completed,
    reset_late_phase_run,
    root_post_task_paused as _root_post_task_paused,
    set_root_post_task_checkpoint as _set_root_post_task_checkpoint,
    settle_terminal_projection as _settle_terminal_projection,
)
from ouroboros.skill_publish_result import apply_skill_publish_receipt_veto
from ouroboros.task_finalization import (
    build_sealed_final_package,
    model_execution_projection,
    build_swarm_efficiency as _build_swarm_efficiency,  # moved (module ceiling); tests import it here
    deliver_final_message_live, prepare_terminal_send_event, register_final_answer_owed, stamp_root_final_phase,
    sealed_final_prompt_section, terminal_result_fields, terminal_notice_text,  # noqa: F401 -- the pipeline module keeps its historical import surface for the synthesis leaf
)
from ouroboros.dialogue_provenance import is_presence_task, presence_provenance_fields  # noqa: F401 -- the pipeline module keeps its historical import surface for the synthesis leaf
from ouroboros.presence_runner import build_presence_result_event

log = logging.getLogger(__name__)


# The synthesis cost/snapshot projections live in `ouroboros/synthesis_cost_text.py`
# (extracted at this module's size ceiling); re-exported here because the
# synthesis prompts, the tests and monkeypatch targets name them on THIS surface.
from ouroboros.synthesis_cost_text import (  # noqa: F401,E402
    _SYNTHESIS_USAGE_PROMPT_FIELDS,
    _summary_row_cost_fields,
    _synthesis_cost_text,
    _synthesis_cost_usd,
    _synthesis_usage_snapshot_text,
)


def _run_post_task_processing_async(
    env: Any,
    task: Dict[str, Any],
    usage: Dict[str, Any],
    llm_trace: Dict[str, Any],
    review_evidence: Dict[str, Any],
    drive_logs: pathlib.Path,
    *,
    blocking: bool = False,
    on_reflection: Callable[[Dict[str, Any] | None, Any], None] | None = None,
    sealed_final: Dict[str, Any] | None = None,
    event_queue: Any = None,
    resume: Dict[str, Any] | None = None,
) -> Dict[str, Any] | None:
    """Run best-effort LLM-heavy post-task memory work off the reply path (``resume``: a saved late-phase Pause)."""
    task_snapshot = json.loads(json.dumps(task, ensure_ascii=False, default=str))
    trace_snapshot = json.loads(json.dumps(llm_trace, ensure_ascii=False, default=str))
    review_evidence_snapshot = json.loads(json.dumps(review_evidence, ensure_ascii=False, default=str))
    sealed_snapshot = (
        json.loads(json.dumps(sealed_final, ensure_ascii=False, default=str))
        if isinstance(sealed_final, dict) and sealed_final else None
    )

    result: Dict[str, Any] = {}
    from ouroboros.usage_accounting import UsageScope, current_usage_scope, usage_scope

    base_scope = current_usage_scope()
    if base_scope is not None:
        post_scope = replace(
            base_scope, category="post_task", source="post_task_synthesis",
        )
    else:
        task_id = str(task_snapshot.get("id") or "")
        post_scope = UsageScope(
            drive_root=task_snapshot.get("budget_drive_root") or env.drive_root,
            task_id=task_id,
            root_task_id=str(task_snapshot.get("root_task_id") or task_id),
            parent_task_id=str(task_snapshot.get("parent_task_id") or ""),
            category="post_task",
            source="post_task_synthesis",
        )

    post_task_key: tuple[str, str] | None = None
    if _is_root_post_task(task_snapshot):
        # The durable checkpoint owns paid idempotency; terminal roots never pay again.
        if _root_post_task_already_completed(env, task_snapshot):
            return None
        if not resume and _root_post_task_paused(env, task_snapshot):
            return None  # only the owner's Resume grant continues a saved late phase
        task_id = str(task_snapshot.get("id") or task_snapshot.get("task_id") or "")
        roots = _root_checkpoint_roots(env, task_snapshot)
        root_key = str(pathlib.Path(
            task_snapshot.get("budget_drive_root")
            or (roots[0] if roots else env.drive_root)
        ).resolve(strict=False))
        post_task_key = (root_key, task_id)
        with _POST_TASK_SYNTHESIS_LOCK:
            if post_task_key in _POST_TASK_SYNTHESIS_INFLIGHT:
                return None
            _POST_TASK_SYNTHESIS_INFLIGHT[post_task_key] = None
        _set_root_post_task_checkpoint(env, task_snapshot, "running")

    # Freeze one honest subtree view synchronously at the pre-synthesis
    # boundary. No scoped worker or consolidation/model call may start first;
    # summary and reflection then receive this same object, while the existing
    # terminal checkpoint remains the only final accounting authority.
    usage_snapshot = resume["usage_snapshot"] if resume else _pre_synthesis_usage_snapshot(env, task_snapshot, usage)

    # The owner's will while the synthesis is ALREADY billing (Stop-now after
    # the loop returned): one local predicate, consulted before EACH paid
    # stage — the durable immediate cancel intent every stop ingress mints
    # and custody keeps open while this worker holds its in-flight key, or
    # the live task marker re-read (the entry snapshot cannot see a stop that
    # landed later). Stop intent stays separate from model-wait choices, whose
    # existing mailbox remains owned until this phase settles.
    intent_root = task_snapshot.get("budget_drive_root") or env.drive_root
    stage_task_id = str(task_snapshot.get("id") or task_snapshot.get("task_id") or "")

    def _owner_stop_requested() -> bool:
        if task.get("_skip_post_task_synthesis"):
            return True
        try:
            from ouroboros.cancel_intents import STOP_POLICY_IMMEDIATE, active_intent, stop_policy

            intent = active_intent(intent_root, stage_task_id)
        except Exception:
            log.debug("cancel-intent read failed for post-task stage gate", exc_info=True)
            return False
        return isinstance(intent, dict) and stop_policy(intent) == STOP_POLICY_IMMEDIATE

    def _run_scoped() -> None:
        checkpoint_status = "degraded"
        skipped: list[str] = []
        interrupted = current = ""
        saved = resume or {}
        free_actions_applied = bool(saved.get("free_actions_applied"))
        completed: list[str] = list(saved.get("completed_stages") or ())
        result.update(saved.get("result") or {})
        late_token = bind_late_phase_run(late := LatePhaseRun(saved.get("marks"), saved.get("drafts")))
        try:
            # The free facts row precedes every paid stage, so neither Stop nor a
            # failed paid stage costs the card its facts; it is not a stage.
            if not resume:
                _record_task_facts(env, task_snapshot, usage_snapshot, trace_snapshot, drive_logs)
            from ouroboros.llm import LLMClient
            from ouroboros.memory import Memory

            llm_client = LLMClient()
            task_memory = Memory(drive_root=env.drive_root, repo_dir=env.repo_dir)

            def _apply_free_reflection() -> None:
                nonlocal free_actions_applied
                entry = result.get("reflection_entry")
                if entry is None or free_actions_applied:
                    return
                # An action may partially apply before raising; never replay it.
                free_actions_applied = True
                try:
                    from ouroboros.project_facts import resolve_project_id
                    _apply_reflection_memory_actions(env, entry, project_id=resolve_project_id(task_snapshot))
                except Exception:
                    log.warning("Completed reflection actions could not be applied for %s", stage_task_id, exc_info=True)

            def _promotion() -> str:
                reflection_entry = result.get("reflection_entry")
                _apply_free_reflection()
                if is_presence_task(task_snapshot):
                    return ""
                # Project facts stay scoped; generic process lessons remain global.
                failure = ""
                try:
                    late_phase_step("promotion:backlog", lambda: _update_improvement_backlog(env, reflection_entry))
                except Exception as error:
                    propagate_paid_interruption(error)
                    # A lost append or grooming pass is this stage's own typed
                    # failure (degraded, nothing skipped); the chooser still runs.
                    failure = "backlog_update_failed"
                    log.warning("Improvement backlog update failed", exc_info=True)
                try:
                    from ouroboros.post_task_evolution import maybe_promote

                    late_phase_step("promotion:promote", lambda: maybe_promote(env, task_snapshot, reflection_entry, llm_client))
                except Exception as error:
                    propagate_paid_interruption(error)
                    # An ordinary chooser failure is this stage's own typed failure
                    # (degraded, nothing skipped); the global callback still runs.
                    failure = "promotion_failed"
                    log.warning("Post-task evolution promotion failed", exc_info=True)
                if on_reflection is not None:
                    late_phase_step("promotion:global", lambda: on_reflection(reflection_entry, llm_client))
                return failure

            # All late model work belongs to this one scoped worker.  This keeps
            # the root checkpoint non-final until the fallback memory draft,
            # consolidation, reflection and promotion have all stopped billing.
            stages: List[tuple[str, Callable[[], Any]]] = [
                ("memory_fallback_draft", lambda: _run_memory_fallback_draft(
                    env, task_snapshot, llm_client, drive_logs, trace_snapshot)),
                ("scratchpad_consolidation", lambda: _run_scratchpad_consolidation(
                    env, task_memory, llm_client)),
                ("reflection", (lambda: finish_published_reflection(env, task_snapshot, result["reflection_entry"]))
                 if saved.get("stage") == "reflection" and result.get("reflection_entry") else
                 lambda: result.__setitem__("reflection_entry", _run_reflection(
                    env, llm_client, task_snapshot, usage_snapshot, trace_snapshot,
                    review_evidence_snapshot, sealed_final=sealed_snapshot,
                    publish=lambda entry: result.__setitem__("reflection_entry", entry)))),
                ("promotion", _promotion),
            ]
            from ouroboros.post_task_synthesis import (
                POST_TASK_INTERRUPT_KINDS, post_task_interruption, propagate_paid_interruption,
            )
            from ouroboros.usage_accounting import BudgetExceeded

            stage_errors = bool(saved.get("stage_errors"))
            for index, (name, run_stage) in enumerate(stages):
                if name in completed:
                    continue
                if _owner_stop_requested():
                    interrupted = "owner_stopped"
                    skipped = [stage for stage, _run in stages[index:]]
                    break
                current = name
                try:
                    stage_reason = run_stage()
                    if name == "reflection" and isinstance(result.get("reflection_entry"), dict):
                        stage_reason = _post_task_paid_interruption(
                            result["reflection_entry"].get("memory_operation_errors"))
                    if isinstance(stage_reason, str) and stage_reason in POST_TASK_INTERRUPT_KINDS:
                        interrupted = stage_reason
                        skipped = [stage for stage, _run in stages[index + 1:]]
                        log.warning("Post-task paid stage %s interrupted for %s: %s",
                                    name, stage_task_id, interrupted)
                        break
                    if isinstance(stage_reason, str) and stage_reason:
                        # A returned ordinary failure is isolated to its stage: later
                        # stages still run, the checkpoint stays degraded (TZ-2 C3).
                        stage_errors = True
                        log.warning("Post-task stage %s failed for %s: %s", name, stage_task_id, stage_reason)
                except Exception as error:
                    # The adapters' own classifier: a control, the wallet and an
                    # unresolved attempt on any provider's chain stop later paid work.
                    try:
                        propagate_paid_interruption(error)
                    except BudgetExceeded:
                        interrupted = "budget_exhausted"
                    except Exception as control:
                        interrupted = post_task_interruption(control)
                    if interrupted:
                        skipped = [stage for stage, _run in stages[index + 1:]]
                        log.warning("Post-task paid stage %s interrupted for %s: %s",
                                    name, stage_task_id, interrupted)
                        break
                    stage_errors = True
                    log.warning("Post-task stage %s failed for %s", name, stage_task_id, exc_info=True)
                completed.append(name)
            if not interrupted and not stage_errors:
                checkpoint_status = "completed"
        except Exception:
            log.warning("Post-task setup failed for %s", stage_task_id, exc_info=True)
        finally:
            if interrupted == "owner_pause" and _owner_stop_requested():  # Stop outranks Pause: nothing saved
                interrupted, skipped = "owner_stopped", [current, *skipped]
            # Applying actions already produced by reflection is free and must
            # survive a later paid-stage refusal; never run the paid promotion here.
            if (result.get("reflection_entry") is not None
                    and interrupted not in {"owner_stopped", "cancelled", "finalize_requested"}
                    and not free_actions_applied):
                _apply_free_reflection()
            # The owner's Pause keeps the remainder (D10); a failed save stays an honest degraded.
            if not (interrupted == "owner_pause" and park_late_phase(
                    env, task_snapshot, current, [current, *skipped], completed, late=late, inputs=(
                        usage, usage_snapshot, trace_snapshot, review_evidence_snapshot, sealed_snapshot, drive_logs,
                        on_reflection), state=dict(result=dict(result), free_actions_applied=free_actions_applied,
                                                   stage_errors=stage_errors))):
                _set_root_post_task_checkpoint(
                    env, task_snapshot, checkpoint_status,
                    stop_reason=(f"{interrupted}:skipped={','.join(skipped)}" if interrupted else ""),
                )
            reset_late_phase_run(late_token)
            if post_task_key is not None:
                with _POST_TASK_SYNTHESIS_LOCK:
                    _POST_TASK_SYNTHESIS_INFLIGHT.pop(post_task_key, None)
            if not in_worker_process():
                # Pooled completion still owes child files and accepted inputs.
                # Its terminal owner cleans up after the first save attempt.
                from supervisor.terminal_delivery import cleanup_settled_owner_mailbox
                cleanup_settled_owner_mailbox(intent_root, stage_task_id, task_snapshot)
                from supervisor.owner_pause_control import late_phase_settled
                late_phase_settled(intent_root, stage_task_id)

    from ouroboros.model_wait import current_model_wait, task_model_wait_scope
    parent_wait = current_model_wait()
    role_overrides = copy.deepcopy(parent_wait.overrides) if parent_wait else {}

    def _run() -> None:
        with usage_scope(post_scope):
            if blocking:
                # Native post-task work retains its call owner after dialogue
                # admission closes; pooled owners stay in their worker process.
                if post_task_key is not None and parent_wait is not None and not parent_wait.worker_slot_held:
                    with _POST_TASK_SYNTHESIS_LOCK:
                        _POST_TASK_SYNTHESIS_INFLIGHT[post_task_key] = parent_wait
                # The task's optional absolute execution ceiling ends the solve
                # phase, not already-started post-work. Calendar deadlines and
                # logical call bounds remain checked before owner_control.
                prior_control = parent_wait.owner_control if parent_wait is not None else None
                if parent_wait is not None:
                    parent_wait.owner_control = lambda: "cancelled" if _owner_stop_requested() else None
                try:
                    _run_scoped()
                finally:
                    if parent_wait is not None:
                        parent_wait.owner_control = prior_control
            else:
                # A detached thread must not inherit its parent's closing scope.
                with task_model_wait_scope(task=task_snapshot, drive_root=env.drive_root,
                                           event_queue=event_queue, worker_slot_held=False,
                                           owner_control=lambda: "cancelled" if _owner_stop_requested() else None) as owner:
                    owner.overrides.update(role_overrides)
                    if post_task_key is not None:
                        with _POST_TASK_SYNTHESIS_LOCK:
                            _POST_TASK_SYNTHESIS_INFLIGHT[post_task_key] = owner
                    _run_scoped()

    if blocking:
        _run()
        return result.get("reflection_entry")
    try:
        settings_context = contextvars.Context()
        copy_task_settings_context(settings_context)
        threading.Thread(target=settings_context.run, args=(_run,), daemon=True).start()
    except Exception:
        _set_root_post_task_checkpoint(env, task_snapshot, "degraded")
        if post_task_key is not None:
            with _POST_TASK_SYNTHESIS_LOCK:
                _POST_TASK_SYNTHESIS_INFLIGHT.pop(post_task_key, None)
        raise
    return None


def recover_pending_root_post_task_synthesis(
    drive_root: Any, repo_dir: Any = None,
    *, exclude_task_ids: frozenset[str] = frozenset(), resume_task_id: str = "",
) -> int:
    """Resume an undispatched root synthesis; degrade an indeterminate one.

    The existing task-result checkpoint is the only durable authority.  The
    process-local in-flight set prevents the periodic reconciler from spawning a
    duplicate while the recovered thread is alive.  After restart only
    ``pending_once`` is replay-safe: ``running`` may have crossed a paid provider
    boundary, so it becomes terminal ``degraded`` instead of repeating calls.
    A ``paused`` late phase is kept and never auto-runs (an unconsumed Resume
    grant is revoked); ``resume_task_id`` consumes that root's live grant.
    """
    from types import SimpleNamespace
    from ouroboros.post_task_synthesis import resume_paused_late_phase, revoke_late_phase_grant
    from ouroboros.task_results import list_task_results
    from ouroboros.terminal_projection import terminal_projection_owed

    root = pathlib.Path(drive_root).resolve(strict=False)
    if resume_task_id:
        return int(resume_paused_late_phase(root, repo_dir or root.parent, str(resume_task_id)))
    try:
        rows = list_task_results(root)
    except Exception:
        return 0
    recovered = 0
    for stored in rows:
        task_id = str(stored.get("task_id") or stored.get("id") or "")
        if task_id in exclude_task_ids:
            continue
        checkpoint = stored.get("root_phase_checkpoint")
        phase = str(checkpoint.get("post_task_synthesis") or "") if isinstance(checkpoint, dict) else ""
        if not task_id:
            continue
        if not _post_task_synthesis_is_open(phase):
            # #1154: a root whose synthesis already settled can still OWE its
            # terminal projection — the process died between the obligation and
            # the Project/Main effects, or Main's eligibility could not be
            # established last pass. Replaying it here is pure bookkeeping on this
            # existing startup scan: no model call, no new timer, no new store. It is not
            # counted as a recovered synthesis, which is what this number means.
            if terminal_projection_owed(task_id, stored):
                _settle_terminal_projection(root, task_id, task={**stored, "id": task_id})
            continue
        if phase == "paused":
            try:
                revoke_late_phase_grant(root, task_id, reason="restart_no_resume")
            except Exception:
                log.warning("Late-phase Resume grant of %s was not revoked at restart", task_id, exc_info=True)
            from supervisor.owner_pause_control import retain_late_phase_latch

            retain_late_phase_latch(root, task_id)
            continue
        task = {**stored, "id": task_id, "root_task_id": str(stored.get("root_task_id") or task_id)}
        task.setdefault("budget_drive_root", str(root))
        if not _is_root_post_task(task):
            continue
        env = SimpleNamespace(
            repo_dir=pathlib.Path(repo_dir or task.get("repo_dir") or root.parent),
            drive_root=root,
            drive_path=lambda rel, _root=root: _root / rel,
        )
        if phase == "running":
            stored = _set_root_post_task_checkpoint(
                env,
                task,
                "degraded",
                stop_reason="restart_indeterminate_running",
            )
            stored_checkpoint = (stored or {}).get("root_phase_checkpoint") or {}
            stored_phase = str(stored_checkpoint.get("post_task_synthesis") or "")
            if not _post_task_synthesis_is_terminal(stored_phase):
                raise RuntimeError(
                    "Root post-task synthesis recovery did not persist a terminal "
                    f"checkpoint for {task_id} (stored={stored_phase or 'unavailable'})"
                )
            recovered += 1
            continue
        usage = {
            # Null stays NULL (C2): `float(... or 0)` turned a task whose cost was
            # never accounted into a confident "$0.00" in the recovered synthesis —
            # a fabricated receipt for the one path (restart recovery) where the
            # amount is least likely to be known.
            "cost": cost_projection(task)["accounted_upper_bound_usd"],
            "rounds": int(task.get("total_rounds") or 0),
            "reason_code": str(task.get("reason_code") or ""),
            "outcome_axes": task.get("outcome_axes") or {},
        }
        trace = {
            "tool_calls": [],
            "reasoning_notes": [str(task.get("trace_summary") or "")],
            "recovered_post_task_synthesis": True,
        }
        _run_post_task_processing_async(
            env, task, usage, trace,
            task.get("review_evidence") if isinstance(task.get("review_evidence"), dict) else {},
            root / "logs", blocking=False,
            # Recovered synthesis gets the same sealed ground truth from the
            # durable record: delivered result text + its artifact facts.
            sealed_final=build_sealed_final_package(task, str(task.get("result") or "")),
        )
        recovered += 1
    return recovered


def _run_global_backlog_promotion_only(
    env: Any,
    task: Dict[str, Any],
    reflection_entry: Dict[str, Any] | None,
    llm: Any,
) -> None:
    """Feed canonical improvement backlog/promotion without leaking project memory.

    Runs inside the promotion stage; a failure raises to that stage's coordinator."""

    if not reflection_entry:
        return
    candidates = [
        item for item in (reflection_entry.get("backlog_candidates") or [])
        if isinstance(item, dict) and str(item.get("summary") or "").strip()
    ]
    if not candidates:
        return
    sanitized_entry = {
        "reflection": "\n".join(f"- {str(item.get('summary') or '').strip()}" for item in candidates),
        "backlog_candidates": candidates,
        "memory_actions": [],
    }
    _update_improvement_backlog(env, sanitized_entry)
    from ouroboros.consciousness_authority import consciousness_origin_metadata
    from ouroboros.post_task_evolution import maybe_promote

    global_task = {
        "id": str(task.get("id") or ""),
        "type": str(task.get("type") or "task"),
        "source": "project_scoped_global_improvement",
        # The origin survives the sanitized view: a campaign a consciousness tree
        # promotes stays inside the consciousness limits.
        "metadata": {"globalized_from_project_task": True, **consciousness_origin_metadata(task.get("metadata"))},
        # The eligibility probe reads the contract (disabled_tools), so the
        # globalized view keeps it: a level that may not evolve stays that way.
        **({"task_contract": dict(task["task_contract"])} if isinstance(task.get("task_contract"), dict) else {}),
    }
    maybe_promote(env, global_task, sanitized_entry, llm)


def _attach_host_mutation_projection(
    env: Any,
    task: Dict[str, Any],
    llm_trace: Dict[str, Any],
) -> None:
    """Bind durable mutation evidence to the existing outcome trace seam."""
    from ouroboros.mutation_attribution import (
        attribution_task_id,
        load_mutation_evidence_projection,
        record_terminal_mutation_candidates,
    )

    task_id = str(task.get("id") or "").strip()
    root_task_id = str(task.get("root_task_id") or task_id).strip()
    task_ids = list(dict.fromkeys(item for item in (root_task_id, task_id) if item))
    metadata = task.get("metadata") if isinstance(task.get("metadata"), dict) else {}
    evidence_root = pathlib.Path(
        task.get("budget_drive_root")
        or metadata.get("budget_drive_root")
        or getattr(env, "budget_drive_root", None)
        or env.drive_root
    )
    # Only the owning root task refreshes its terminal candidate snapshot at
    # outcome derivation; a subagent never rewrites the root's evidence.
    if task_id and task_id == root_task_id:
        try:
            if attribution_task_id(evidence_root, (task_id,)) == task_id:
                record_terminal_mutation_candidates(evidence_root, task_id)
        except Exception:
            log.debug("terminal mutation snapshot failed for %s", task_id, exc_info=True)
    llm_trace.pop("mutation_attribution", None)
    for candidate in task_ids:
        projection = load_mutation_evidence_projection(evidence_root, candidate)
        if projection:
            llm_trace["mutation_attribution"] = projection
            return


def _derive_host_bound_loop_outcome(
    env: Any,
    task: Dict[str, Any],
    text: str,
    usage: Dict[str, Any],
    llm_trace: Dict[str, Any],
) -> Dict[str, Any]:
    """Derive once from the current durable mutation-evidence binding."""
    _attach_host_mutation_projection(env, task, llm_trace)
    loop_outcome = apply_skill_publish_receipt_veto(derive_loop_outcome(text or "", usage, llm_trace), task, llm_trace)
    return _apply_terminal_custody_outcome(env, task, loop_outcome)


def _apply_terminal_custody_outcome(
    env: Any, task: Dict[str, Any], loop_outcome: Dict[str, Any],
) -> Dict[str, Any]:
    """Make the terminal custody audit authoritative for result and event axes."""

    drive_root = task.get("budget_drive_root") or getattr(env, "drive_root", None)
    if drive_root is None:
        return loop_outcome
    existing = load_task_result(drive_root, str(task.get("id") or "")) or {}
    unreconciled = existing.get("delegated_runs_unreconciled")
    if not isinstance(unreconciled, list) or not unreconciled:
        return loop_outcome
    overlaid = {
        **loop_outcome,
        "reason_code": "delegated_custody_unreconciled",
        "outcome_axes": custody_debt_axes(loop_outcome.get("outcome_axes")),
    }
    # A task truncated by the rails keeps ITS reason on the one Reason line; the
    # custody debt rides objective.warning(s) and the row's debt list instead.
    rail = str(loop_outcome.get("reason_code") or "")
    if rail in BEST_EFFORT_REASON_CODES:
        overlaid["reason_code"] = rail
    return overlaid


def _stamp_project_room_pointer(task: Dict[str, Any], env: Any) -> None:
    """The project's last-result POINTER for a room's direct-chat root.

    A project ROOM's direct-chat turn writes a durable result carrying
    ``project_id`` but no letters home, so the pointer stayed empty and the
    room's own results were never offered as predecessors. Only the pointer is
    written here: no milestone, work-location row, digest or blocking
    post-processing - that exclusion is deliberate and stands.
    """
    from ouroboros.project_facts import resolve_project_id
    from ouroboros.tools.project_journal import record_project_last_result

    record_project_last_result(
        resolve_project_id(task), str(task.get("id") or ""),
        pathlib.Path(str(task.get("budget_drive_root") or env.drive_root)),
    )


def _custody_debt_event_fields(stored_result: Dict[str, Any]) -> Dict[str, Any]:
    """Carry the row's own custody debt list onto the live terminal event.

    The stamped code outlives the fact, so the owner-facing Reason line names
    the custody warning only while the record's own ``delegated_runs_unreconciled``
    list is non-empty (docs/ARCHITECTURE.md, terminal composition). Both
    renderers read that list off the record in front of them, and the card reads
    this event rather than the durable row, so the event carries a copy of the
    stored list. A row holding no list states nothing about the debt: absence
    stays absence instead of becoming a second, guessed rule on one surface.
    """
    debt = stored_result.get("delegated_runs_unreconciled")
    return {"delegated_runs_unreconciled": list(debt)} if isinstance(debt, list) else {}


def _stamp_presence_terminal_facts(
    task: Dict[str, Any], usage: Dict[str, Any], llm_trace: Dict[str, Any], ctx: Any, reason_code: str,
) -> None:
    """Typed Presence facts the Host guard reads back from the durable row's metadata."""
    from ouroboros.presence_runner import presence_retry_proof, presence_unknown_outcome

    metadata = task.get("metadata") if isinstance(task.get("metadata"), dict) else {}
    if reason_code == "resource_refusal_no_resend":
        proof = presence_retry_proof(task, usage, llm_trace, ctx)
        if proof:
            task["metadata"] = metadata = {**metadata, "presence_retry_proof": proof}
    # The loop's own no-resend predicate, stamped where the Host guard reads the row back: a
    # dispatched attempt left unresolved is not answered by the rail's text or a salvaged draft.
    unknown = presence_unknown_outcome(usage)
    if unknown:
        task["metadata"] = {**metadata, "presence_unknown_outcome": unknown}


def emit_task_results(
    env: Any, memory: Any, llm: Any,
    pending_events: List[Dict[str, Any]],
    task: Dict[str, Any], text: str,
    usage: Dict[str, Any], llm_trace: Dict[str, Any],
    start_time: float, drive_logs: pathlib.Path,
    ctx: Any = None, event_queue: Any = None,
) -> None:
    """Emit all end-of-task events to supervisor and run post-task processing."""
    from ouroboros.subagent_bootstrap import actor_first_terminal_projection
    actor_fact, usage, llm_trace = actor_first_terminal_projection(ctx, task, usage, llm_trace, task.get("budget_drive_root") or getattr(env, "drive_root", None))
    loop_outcome = _derive_host_bound_loop_outcome(env, task, text, usage, llm_trace)
    receipt_root = pathlib.Path(str(getattr(env, "drive_root", None) or "."))
    verification_receipts = task_verification_receipts(ctx, receipt_root, task)
    # Apply FR3 once so events and the durable result share the same flagged outcome.
    apply_receipt_absent_flag(
        loop_outcome, llm_trace, receipt_root, str(task.get("id") or ""),
        expected_output=str(task.get("expected_output") or ""), receipts=verification_receipts,
    )
    outcome_axes = normalize_outcome_axes({"outcome_axes": loop_outcome.get("outcome_axes")})
    execution_status = str((outcome_axes.get("execution") or {}).get("status") or "")
    failed_or_forced = (
        execution_status in {EXECUTION_FAILED, EXECUTION_INFRA_FAILED, EXECUTION_BEST_EFFORT}
        or str(usage.get("execution_status") or usage.get("result_status") or "") in {EXECUTION_FAILED, EXECUTION_INFRA_FAILED}
    )
    if ctx is not None and failed_or_forced:
        ctx._presence_completion_accepted = False
    reason_code = str(loop_outcome.get("reason_code") or "")
    if is_presence_task(task):
        _stamp_presence_terminal_facts(task, usage, llm_trace, ctx, reason_code)
    # A Stop marker already on the task suppresses paid synthesis, not the durable outbox or free facts.
    _root_outbox = _is_root_post_task({k: v for k, v in task.items() if k != "_skip_post_task_synthesis"})
    if getattr(ctx, "_skip_post_task_synthesis", False):   # "Stop now": paid root predicates see it
        task["_skip_post_task_synthesis"] = True
    _presence = is_presence_task(task)
    _typed_routing_action = str(getattr(ctx, "_typed_routing_action_emitted", "") or "").strip()
    # The final frame's durable identity: the child lineage and the turn's
    # origin label (a wake-up's "consciousness"), so the chat row keeps both.
    _message_meta = {**subagent_message_meta(task, task_id=str(task.get("id") or "")), **initiator_meta(task)}
    from ouroboros.post_task_synthesis import task_tool_metrics
    tool_metrics = task_tool_metrics(llm_trace)
    send_event = {
        "type": "send_message", "chat_id": task["chat_id"],
        "text": text or "\u200b", "log_text": text or "",
        "format": "markdown",
        "task_id": task.get("id"), "ts": utc_now_iso(),
    }
    if _message_meta:
        # Final frames carry their own durable identity; replay must not depend
        # on a nearby progress row that may age out independently.
        send_event["progress_meta"] = dict(_message_meta)
    send_event = prepare_terminal_send_event(env.drive_root, task, text, usage, send_event, presence=_presence)
    pending_events.append(build_presence_result_event(
        task, text, ctx, terminal_origin=str(usage.get("terminal_origin") or ""),
        retain_scheduled_handoff=failed_or_forced,
    ) if _presence else send_event)
    duration_sec = round(time.time() - start_time, 3)
    try:
        from supervisor.state import reconstruct_task_cost

        task_cost_fields = reconstruct_task_cost(
            str(task.get("id") or ""), fields=True,
            drive_root=pathlib.Path(task.get("budget_drive_root") or env.drive_root),
        )
        from ouroboros.cost_projection import with_task_cost_presentation

        task_cost_fields = with_task_cost_presentation(task_cost_fields, task, env.drive_root)
    except Exception:
        log.error("Task cost authority unavailable at finalization", exc_info=True)
        task_cost_fields = {
            "cost_accounting_status": "unavailable", "cost_final": False,
            "cost_accounting_error": "ledger_unavailable",
            "accounted_upper_bound_usd": None, "total_rounds": None,
            "prompt_tokens": None, "completion_tokens": None,
            "reserved_usd": None, "unresolved_upper_bound_usd": None,
            "unknown_unmetered": None,
            "cost_presentation": None,
        }
    # SSOT cost naming (C2/ABI-3): the honest names on every terminal frame
    # this pipeline emits; the seam also strips any legacy alias spelling.
    from ouroboros.cost_projection import with_cost_aliases

    task_cost_fields = with_cost_aliases(task_cost_fields)
    if _is_root_post_task(task) and not _root_post_task_already_completed(env, task):
        task_cost_fields["cost_final"] = False
    try:
        append_jsonl(drive_logs / "events.jsonl", {
            "ts": utc_now_iso(), "type": "task_eval", "ok": execution_status not in {EXECUTION_FAILED, EXECUTION_INFRA_FAILED},
            "task_id": task.get("id"), "task_type": task.get("type"),
            "outcome_axes": outcome_axes,
            "reason_code": reason_code,
            "review_eligibility": str(loop_outcome.get("review_eligibility") or ""),
            "review_trigger": str(loop_outcome.get("review_trigger") or ""),
            "duration_sec": duration_sec,
            **tool_metrics,
            "response_len": len(text),
        })
    except Exception:
        log.warning("Failed to log task eval event", exc_info=True)
    pending_events.append({
        "type": "task_metrics",
        "task_id": task.get("id"), "task_type": task.get("type"),
        "outcome_axes": outcome_axes,
        "reason_code": reason_code,
        "duration_sec": duration_sec,
        **tool_metrics,
        **task_cost_fields,
        **({"resource_limit": dict(usage.get("resource_limit") or {})}
           if isinstance(usage.get("resource_limit"), dict) else {}),
        "ts": utc_now_iso(),
    })

    review_evidence: Dict[str, Any] = {}
    try:
        from ouroboros.review_evidence import collect_review_evidence

        review_evidence = collect_review_evidence(
            env.drive_root,
            task_id=str(task.get("id") or ""),
            repo_dir=getattr(env, "repo_dir", None),
        )
    except Exception:
        log.debug("Failed to collect review evidence", exc_info=True)

    from ouroboros.post_task_synthesis import capture_task_inputs
    review_evidence["task_inputs"] = capture_task_inputs(
        ctx, task, task.get("budget_drive_root") or receipt_root, verification_receipts,
    )

    # GR2-5 (§8-A2, ONE outbox for EVERY root) + GR3-5 (ordering closes the
    # persist→register crash window): the final answer enters the durable
    # outbox — the owed row embeds the full payload — immediately BEFORE
    # the durable result write, regardless of the blocking/nonblocking
    # post-task split below. Registered-then-crashed leaves an owed row
    # boot replay delivers (projection-over-replay: no boot scan of
    # task_results is ever needed); the old stored-then-crashed order left
    # a terminal result nobody would ever deliver. The nonblocking lane
    # used to buffer the send with no delivery_id and no owed registration
    # at all. Seam + dedup: ouroboros/task_finalization.py.
    if _root_outbox and not _presence:
        send_event.setdefault("progress_meta", {}).update(outcome_axes=outcome_axes, reason_code=reason_code)
        stamp_root_final_phase(  # the stamp names the SAME word the durable row below settles to
            send_event, task, terminal_status=_durable_terminal_status(env, task, execution_status),
            post_task_open=not task.get("_skip_post_task_synthesis") and not _root_post_task_already_completed(env, task),
        )
        register_final_answer_owed(task, send_event, env_drive_root=env.drive_root)
    _store_task_result(
        env, task, text, usage, llm_trace, review_evidence=review_evidence,
        loop_outcome=loop_outcome, cost_fields=task_cost_fields, final_delivery=send_event,
    )
    stored_result = load_task_result(env.drive_root, str(task.get("id") or "")) or {}
    if _root_outbox and task.get("_skip_post_task_synthesis"):
        # Stop before post-task dispatch forbids paid synthesis, not the free
        # factual row. Record it after durable result write; the structural
        # root predicate deliberately excludes stopped roots from recovery.
        fact_usage = {**usage, "outcome_axes": outcome_axes, "reason_code": reason_code}
        if _typed_routing_action:
            fact_usage["typed_routing_action"] = _typed_routing_action
        _record_task_facts(env, task, _pre_synthesis_usage_snapshot(env, task, fact_usage),
                           llm_trace, drive_logs)
    artifact_bundle = stored_result.get("artifact_bundle") if isinstance(stored_result.get("artifact_bundle"), dict) else {}
    review_projection = stored_result.get("review_projection") or {}
    pending_events.append({
        "type": "task_done",
        "task_id": task.get("id"),
        "task_type": task.get("type"),
        # GR2-3c: the DURABLE status rides the event for honesty — the
        # supervisor validates every task_done against the durable row;
        # a stamped status makes the event self-describing.
        "status": str(stored_result.get("status") or ""),
        "_is_direct_chat": bool(task.get("_is_direct_chat")),
        **({"typed_routing_action": _typed_routing_action} if _typed_routing_action else {}),
        **({"model_execution": send_event["progress_meta"]["model_execution"]}
           if "model_execution" in send_event.get("progress_meta", {}) else {}),
        # Carry the thread so the terminal card finalizes in its project panel
        # (per-thread fan-out), not just the main chat.
        "chat_id": int(task.get("chat_id") or 0),
        "outcome_axes": outcome_axes, "reason_code": reason_code,
        **_custody_debt_event_fields(stored_result),
        "artifact_status": artifact_bundle.get("status") or stored_result.get("artifact_status") or "",
        "artifact_bundle": artifact_bundle,
        "review_status": stored_result.get("review_status") if isinstance(stored_result.get("review_status"), dict) else {},
        **({"review_projection": review_projection} if review_projection.get("panels") else {}),
        **task_cost_fields,
        # v6.57.0 (P6b): recursive cost incl. children (from the stored rollup) so the
        # parent card / Logs can show the true subtree cost, not just this task's own.
        # ABI-3: honest name only; a legacy stored spelling still resolves.
        "accounted_upper_bound_usd_with_children": resolve_cost_pair(
            stored_result, "accounted_upper_bound_usd_with_children", "cost_usd_with_children")[1],
        "cost_with_children_partial": bool(stored_result.get("cost_with_children_partial")),
        **({"resource_limit": dict(usage.get("resource_limit") or {})}
           if isinstance(usage.get("resource_limit"), dict) else {}),
        "ts": utc_now_iso(),
    })
    # NOTE: task_done is NOT written to events.jsonl here.
    # It goes through EVENT_Q → supervisor _handle_task_done → append_jsonl.
    # This ensures causal ordering: send_message reaches the UI before task_done,
    # preventing the live card from collapsing before the assistant reply arrives.
    restart_reason = str(getattr(ctx, "pending_restart_reason", "") or "").strip()
    evolution_restart = bool(getattr(ctx, "pending_restart_is_evolution", False))
    if restart_reason:
        if not evolution_restart:
            pending_events.append({
                "type": "restart_request", "reason": restart_reason,
                "evolution_restart": False, "ts": utc_now_iso(),
            })
        ctx.pending_restart_reason = None
        ctx.pending_restart_is_evolution = False

    if _is_root_post_task(task):
        post_usage = dict(usage or {})
        post_usage["outcome_axes"] = outcome_axes
        post_usage["reason_code"] = reason_code
        if _typed_routing_action:
            post_usage["typed_routing_action"] = _typed_routing_action
        from ouroboros.project_facts import resolve_project_id

        _project_scoped = bool(resolve_project_id(task))
        # A project THREAD conversation runs on the fast direct-chat lane. It is
        # project-scoped only for CONTEXT (it sees the project's knowledge/
        # journal), but it is NOT a pooled task completion: it must not block the
        # reply on LLM post-processing and must not write letters home (that
        # would turn every "как дела?" into a journal milestone + a consciousness
        # observation and stall the global chat lock). Only real pooled project
        # tasks get the letters-home + blocking treatment.
        _is_direct_chat = bool(task.get("_is_direct_chat"))
        _project_task = _project_scoped and not _is_direct_chat
        if _project_task:
            # Letters home (v6.32.0): record the cycle in the project's own
            # journal and emit a concise completion digest for consciousness
            # (project_id + full objective + outcome). Full project awareness:
            # this is a crisp "task finished" summary, not an isolation boundary —
            # the one mind already sees the project thread in its unified memory;
            # only per-cycle RAW internal facts stay in the per-project store.
            _pid = resolve_project_id(task)
            # The full objective IS the meaning of the cycle — carry it whole into
            # the journal milestone and the consciousness digest (BIBLE P1: no
            # silent/lossy clip of cognitive text). Objectives are concise by
            # nature; the task and task_results remain the durable record.
            _objective = str(task.get("objective") or task.get("description") or task.get("text") or "")
            _exec_status = str((outcome_axes.get("execution") or {}).get("status") or "unknown")
            try:
                # One fail-soft seam (project_journal.record_task_finalization) for
                # the durable letters home: the task-finished milestone, the Q8
                # off-registry work-location row, and — for the swarm ROOT — the
                # tree-ledger coordination mirror. Kind compares against the
                # canonical execution-axis constants (EXECUTION_OK is "ok"; a raw
                # "success" literal never matched — the C9.1 seed bug).
                from ouroboros.tools.project_journal import record_task_finalization

                record_task_finalization(
                    _pid,
                    task,
                    objective=_objective,
                    kind="done" if _exec_status in (EXECUTION_OK, EXECUTION_BEST_EFFORT) else "blocked",
                    exec_status=_exec_status,
                    # Registry lives on the canonical drive; stamps the durable
                    # per-project last-result pointer.
                    drive_root=pathlib.Path(str(task.get("budget_drive_root") or env.drive_root)),
                )
            except Exception:
                log.debug("project journal finalization entries failed", exc_info=True)
            try:
                _task_metadata = task.get("metadata") if isinstance(task.get("metadata"), dict) else {}
                pending_events.append({
                    "type": "project_digest",
                    "project_id": _pid,
                    "task_id": str(task.get("id") or ""),
                    # The alarm clock must not re-arm on a tree consciousness started.
                    "initiator": str(_task_metadata.get("initiator") or ""),
                    "objective": _objective,
                    "execution_status": _exec_status,
                    "objective_status": str((outcome_axes.get("objective") or {}).get("status") or "not_evaluated"),
                    "ts": utc_now_iso(),
                })
            except Exception:
                log.debug("project digest emission failed", exc_info=True)
        elif _project_scoped:
            _stamp_project_room_pointer(task, env)
        budget_drive_root = str(task.get("budget_drive_root") or "").strip()
        split_drive = bool(
            budget_drive_root
            and str(pathlib.Path(budget_drive_root).resolve(strict=False)) != str(pathlib.Path(env.drive_root).resolve(strict=False))
        )
        parent_env = None
        parent_task = None
        if split_drive:
            from types import SimpleNamespace

            parent_env = SimpleNamespace(repo_dir=env.repo_dir, drive_root=pathlib.Path(budget_drive_root), drive_path=lambda rel: pathlib.Path(budget_drive_root) / rel)
            parent_task = {**task, "drive_root": budget_drive_root, "child_drive_root": str(env.drive_root)}

        if not _root_post_task_already_completed(env, task):
            _dispatch_root_post_task(
                env, task, str(send_event.get("text") or ""), event_queue, pending_events,
                post_usage, llm_trace, review_evidence, drive_logs,
                budget_drive_root=budget_drive_root, split_drive=split_drive,
                project_scoped=_project_scoped, project_task=_project_task,
                parent_env=parent_env, parent_task=parent_task,
            )


def _dispatch_root_post_task(
    env: Any, task: Dict[str, Any], text: str,
    event_queue: Any, pending_events: List[Dict[str, Any]],
    post_usage: Dict[str, Any], llm_trace: Dict[str, Any],
    review_evidence: Dict[str, Any], drive_logs: pathlib.Path,
    *, budget_drive_root: str, split_drive: bool,
    project_scoped: bool, project_task: bool,
    parent_env: Any, parent_task: Dict[str, Any] | None,
) -> None:
    """Live final-answer delivery + sealed ground truth + post-task dispatch.

    The owner's answer goes out BEFORE blocking post-task cognition; task_done
    stays LAST via the buffered return (early task_done would release the
    queue slot / start child-drive cleanup mid-post-task). Rationale and the
    never-lost/never-doubled delivery contract: ouroboros/task_finalization.py.
    """
    split = split_drive and parent_env is not None and parent_task is not None
    global_reflection_callback = None
    if split and project_scoped:
        global_reflection_callback = functools.partial(
            _run_global_backlog_promotion_only, parent_env, parent_task)
    split_non_project = split and not project_scoped
    blocking = in_worker_process() or bool(task.get("_is_direct_chat")) or split_non_project or (
        str(task.get("type") or "") == "evolution"
        or bool(str(task.get("workspace_root") or "").strip())
        or bool(str(task.get("workspace_mode") or "").strip())
        or project_task
    )
    if (is_presence_task(task) and task.get("_is_direct_chat")
            and not in_worker_process() and not split_drive):
        # The native adapter receives the durable result on return. Its request
        # must not wait for synthesis; pooled/forked workers retain their custody.
        blocking = False
    if blocking and event_queue is not None:
        # The CANONICAL data root — what the supervisor's boot/tick outbox
        # replay reads (§8-A2): the parent/budget root for split children, the
        # task's own drive for an ordinary root (whose ``budget_drive_root``
        # field is legitimately empty).
        deliver_final_message_live(
            event_queue, pending_events, str(task.get("id") or ""),
            drive_root=budget_drive_root or env.drive_root,
        )
    # Sealed ground truth for summary/reflection: what the owner actually
    # received + the durable result's own artifact facts (Q4A).
    sealed_final = build_sealed_final_package(
        load_task_result(env.drive_root, str(task.get("id") or "")), text,
    )
    if split_non_project:
        _run_post_task_processing_async(
            parent_env, parent_task, post_usage, llm_trace, review_evidence,
            pathlib.Path(budget_drive_root) / "logs",
            blocking=True, sealed_final=sealed_final, event_queue=event_queue,
        )
    else:
        _run_post_task_processing_async(
            env, task, post_usage, llm_trace, review_evidence, drive_logs,
            blocking=blocking,
            on_reflection=global_reflection_callback,
            sealed_final=sealed_final,
            event_queue=event_queue,
        )


def _durable_terminal_status(
    env: Any, task: Dict[str, Any], execution_status: str, *, existing: Dict[str, Any] | None = None,
) -> str:
    """The status the durable task row settles to (ONE rule for the row and its outbox stamp).

    A failed execution axis — including the owner's "Stop now", whose forced
    finalization stamps ``execution_status="failed"`` under
    ``owner_requested_finalization`` — and an already-failed row both settle
    ``failed``; everything else settles ``completed``.
    """
    if existing is None:
        existing = load_task_result(env.drive_root, str(task.get("id") or "")) or {}
    failed = (
        str(existing.get("status") or "") == STATUS_FAILED
        or execution_status in {EXECUTION_FAILED, EXECUTION_INFRA_FAILED}
    )
    return STATUS_FAILED if failed else STATUS_COMPLETED


def _store_task_result(env: Any, task: Dict[str, Any], text: str,
                       usage: Dict[str, Any], llm_trace: Dict[str, Any],
                       review_evidence: Dict[str, Any] | None = None,
                       loop_outcome: Dict[str, Any] | None = None,
                       cost_fields: Dict[str, Any] | None = None,
                       final_delivery: Dict[str, Any] | None = None) -> None:
    """Store task result for parent task retrieval.

    ``loop_outcome``, when supplied by ``emit_task_results``, is the SINGLE already-
    derived, already-receipt_absent-flagged outcome that also fed the task_eval /
    task_metrics event stream — so the persisted axes match the events exactly and we
    do not derive/flag a second time. It is only re-derived here when called without one.
    """
    try:
        from ouroboros.review_projection import publish_acceptance_checkpoint

        publish_acceptance_checkpoint(env, llm_trace, task_id=str(task.get("id") or ""),
                                      drive_root=env.drive_root, chat_id=task.get("chat_id"))
        trace_summary = build_trace_summary(llm_trace)
        from ouroboros.cost_projection import with_cost_aliases

        cost_fields = with_cost_aliases(cost_fields or {
            "cost_accounting_status": "unavailable", "cost_final": False,
            "cost_accounting_error": "ledger_projection_missing",
            "cost_presentation": None,
            "accounted_upper_bound_usd": None, "total_rounds": None,
            "prompt_tokens": None, "completion_tokens": None,
            "reserved_usd": None, "unresolved_upper_bound_usd": None,
            "unknown_unmetered": None,
        })
        existing = load_task_result(env.drive_root, str(task.get("id") or "")) or {}
        if loop_outcome is None:
            loop_outcome = _derive_host_bound_loop_outcome(env, task, text, usage, llm_trace)
            # Apply FR3 before normalization so the persisted axes and ledger agree.
            apply_receipt_absent_flag(
                loop_outcome, llm_trace, env.drive_root, str(task.get("id") or ""),
                expected_output=str(task.get("expected_output") or ""),
                receipts=task_verification_receipts(None, env.drive_root, task),
            )
        loop_outcome = _apply_terminal_custody_outcome(env, task, loop_outcome)
        outcome_axes = normalize_outcome_axes({"outcome_axes": loop_outcome.get("outcome_axes")})
        execution_status = str((outcome_axes.get("execution") or {}).get("status") or "")
        reason_code = str(loop_outcome.get("reason_code") or "")
        status = _durable_terminal_status(env, task, execution_status, existing=existing)
        from ouroboros.task_finalization import build_completion_observations

        observations = build_completion_observations(
            env.drive_root, {**task, "started_at": existing.get("started_at")}, llm_trace,
        )
        task_contract = build_task_contract(task)
        task = {**task, "task_contract": task_contract}
        artifact_bundle_for_ledger = artifact_bundle_from_result(existing)
        verification_ledger = build_verification_ledger(
            task=task,
            loop_outcome=loop_outcome,
            llm_trace=llm_trace,
            artifact_bundle=artifact_bundle_for_ledger,
            review_evidence=review_evidence or {},
        )
        verification_refs = maybe_write_verification_artifact(
            env.drive_root,
            str(task.get("id") or ""),
            verification_ledger,
        )
        artifacts = list(existing.get("artifacts") or []) if isinstance(existing.get("artifacts"), list) else []
        artifact_record = verification_refs.get("artifact")
        if artifact_record and artifact_record not in artifacts:
            artifacts.append(artifact_record)
        # An eligible forced/launch-skip answer must not re-hash artifact bodies
        # on its urgent terminal path. Existing registrations and copyback own them.
        collected_artifacts = collect_task_artifact_records(
            env.drive_root, str(task.get("id") or ""), measure="acceptance_history_seed" not in llm_trace,
        )
        artifacts = merge_artifact_records(artifacts, collected_artifacts)
        provisional = {
            **existing,
            "artifacts": artifacts,
        }
        artifact_bundle = artifact_bundle_from_result(provisional)
        outcome_axes = dict(outcome_axes)
        existing_artifact_axis = (
            (existing.get("outcome_axes") or {}).get("artifacts")
            if isinstance(existing.get("outcome_axes"), dict)
            else {}
        )
        artifact_axis = dict(existing_artifact_axis) if isinstance(existing_artifact_axis, dict) else {}
        if isinstance(outcome_axes.get("artifacts"), dict):
            artifact_axis.update(outcome_axes.get("artifacts") or {})
        artifact_axis["status"] = str(artifact_bundle.get("status") or artifact_axis.get("status") or "not_applicable")
        outcome_axes["artifacts"] = artifact_axis
        # B1: swarm-efficiency rollup — observed fan-out, or the zero-fanout
        # block for a host-attested Swarm task; None (omitted) for plain tasks.
        swarm_efficiency = _build_swarm_efficiency(env, task)
        subagent_envelope = task.get("subagent_envelope") if isinstance(task.get("subagent_envelope"), dict) else {}
        if str(task.get("delegation_role") or "").lower() == "subagent":
            subagent_envelope = envelope_from_task(
                task, status=status, usage=usage,
                accounted_upper_bound_usd=cost_fields.get("accounted_upper_bound_usd"),
            )
            if cost_fields.get("cost_accounting_status") != "available":
                subagent_envelope.update({
                    "accounted_upper_bound_usd": None,
                    "cost_accounting_status": "unavailable",
                    "cost_final": False,
                })
        # Compatibility projection only. The physical-attempt ledger is the sole
        # monetary authority; the supervisor replaces the root projection with the
        # exact subtree total at terminal handling. Do not independently walk task
        # results here: that was a second accounting engine and could double-count.
        _own_cost = cost_fields.get("accounted_upper_bound_usd")
        _cost_with_children = _own_cost
        _cost_partial = True
        root_phase_checkpoint: Dict[str, Any] = {}
        if _is_root_post_task(task):
            incoming_checkpoint = llm_trace.get("root_phase_checkpoint")
            existing_checkpoint = existing.get("root_phase_checkpoint")
            if (
                isinstance(existing_checkpoint, dict)
                and _post_task_synthesis_is_terminal(
                    existing_checkpoint.get("post_task_synthesis")
                )
            ):
                root_phase_checkpoint = dict(existing_checkpoint)
            elif isinstance(incoming_checkpoint, dict):
                root_phase_checkpoint = dict(incoming_checkpoint)
            elif isinstance(existing_checkpoint, dict):
                root_phase_checkpoint = dict(existing_checkpoint)
            else:
                root_phase_checkpoint = {
                    "phase": "task_acceptance",
                    "status": "not_required",
                    "pass_index": 0,
                }
            root_phase_checkpoint.setdefault("post_task_synthesis", "pending_once")
        review_projection = _compact_review_projection(llm_trace)
        model_execution = model_execution_projection(usage)
        from ouroboros.acceptance_history import retain_acceptance_history
        history_fields = retain_acceptance_history(
            env.drive_root, task, text, llm_trace, review_evidence or {},
            observations, artifacts, final_delivery,
        )
        write_task_result(
            env.drive_root,
            str(task.get("id") or ""),
            status,
            _terminal_observed=True,
            reason_code=reason_code,
            outcome_axes=outcome_axes,
            # Compatibility mirror consumed by the gateway and task_done event.
            # ``outcome_axes.review`` remains the canonical structured axis.
            review_status=dict(outcome_axes.get("review") or {}),
            accounted_upper_bound_usd_with_children=_cost_with_children,
            cost_with_children_partial=_cost_partial,
            task_contract=task_contract,
            _is_direct_chat=bool(task.get("_is_direct_chat")),
            loop_outcome=loop_outcome,
            project_id=str(task.get("project_id") or ""),
            parent_task_id=task.get("parent_task_id"),
            root_task_id=task.get("root_task_id"),
            session_id=task.get("session_id"),
            actor_id=task.get("actor_id"),
            delegation_role=task.get("delegation_role"),
            role=task.get("role"),
            description=task.get("description"),
            objective=task.get("objective") or task.get("description"),
            title=task.get("title"),
            expected_output=task.get("expected_output"),
            constraints=task.get("constraints"),
            context=task.get("context"),
            workspace_root=task.get("workspace_root"),
            workspace_mode=task.get("workspace_mode"),
            memory_mode=task.get("memory_mode"),
            drive_root=task.get("drive_root"),
            child_drive_root=task.get("child_drive_root") or task.get("drive_root"),
            budget_drive_root=task.get("budget_drive_root"),
            task_constraint=task.get("task_constraint"),
            model_lane=task.get("model_lane"),
            requested_model_lane=task.get("requested_model_lane"),
            parent_model_lane=task.get("parent_model_lane"),
            requested_executor=task.get("requested_executor"),
            effective_model_lane=task.get("effective_model_lane"),
            model=task.get("model"),
            use_local_model=task.get("use_local_model"),
            effective_executor=task.get("effective_executor"),
            executor_route=task.get("executor_route"),
            tool_profile=task.get("tool_profile"),
            capability_delta=subagent_envelope.get("capability_delta") or task.get("capability_delta"),  # Q1A: envelope copy carries the native_only amendment
            **substrate_result_fields(subagent_envelope),  # Q1A: substrate FACT + raw counts
            reasoning_effort=task.get("reasoning_effort"),
            task_group_id=task.get("task_group_id"),
            task_group=task.get("task_group"),
            subagent_envelope=subagent_envelope,
            configured_subagent=task.get("configured_subagent"),
            parent_cognitive_route=task.get("parent_cognitive_route"),
            subagent_availability=task.get("subagent_availability"),
            metadata=task.get("metadata") if isinstance(task.get("metadata"), dict) else {},
            result=text or "", **terminal_result_fields(usage),
            final_answer=str(loop_outcome.get("final_answer") or ""),
            trace_summary=trace_summary,
            trace_refs=loop_outcome.get("trace_refs") or {},
            **({"model_execution": model_execution} if model_execution is not None else {}),
            **cost_fields,
            review_evidence=review_evidence or {},
            completion_observations=observations,
            **({"review_projection": review_projection} if review_projection.get("panels") else {}),
            verification_ledger=verification_refs.get("inline"),
            artifact_bundle=artifact_bundle,
            artifacts=artifacts,
            **history_fields,
            **({"root_phase_checkpoint": root_phase_checkpoint} if root_phase_checkpoint else {}),
            **({"swarm_efficiency": swarm_efficiency} if swarm_efficiency else {}),
            ts=utc_now_iso(),
        )
    except Exception as e:
        log.warning("Failed to store task result: %s", e)
        return
    try:
        from ouroboros.subagent_history import record_task_execution
        record_task_execution(task, usage, drive_root=task.get("budget_drive_root") or env.drive_root)
    except Exception as e:
        log.warning("Task result stored; subagent history unavailable: %s", e)


def build_review_context(env: Any) -> str:
    """Build a compact review continuity section for the main reasoning context."""
    try:
        from ouroboros.review_state import (
            _LEGACY_CURRENT_REPO_KEY,
            advisory_commit_ready,
            compute_snapshot_hash,
            format_status_section,
            load_state,
            make_repo_key,
        )
        from ouroboros.task_continuation import (
            list_review_continuations,
            retire_settled_continuations_for_context,
        )
        from ouroboros.task_results import load_task_result

        state = load_state(pathlib.Path(env.drive_root))
        retired = retire_settled_continuations_for_context(
            env.drive_root, state, lambda tid: load_task_result(env.drive_root, tid))
        continuations, corrupt = list_review_continuations(env.drive_root)
        repo_dir = pathlib.Path(env.repo_dir)
        repo_key = make_repo_key(repo_dir)
        snapshot_hash = compute_snapshot_hash(repo_dir)
        open_obs = state.get_open_obligations(repo_key=repo_key)
        open_debts = state.get_open_commit_readiness_debts(repo_key=repo_key)
        if (
            not state.advisory_runs
            and not state.latest_attempt()
            and not continuations
            and not corrupt
            and not open_obs
            and not open_debts
        ):
            return ""

        current_run = None
        for run in reversed(state.advisory_runs):
            if run.snapshot_hash != snapshot_hash:
                continue
            if run.repo_key not in ("", repo_key, _LEGACY_CURRENT_REPO_KEY):
                continue
            current_run = run
            break

        # H5 (capinv-447): honestly named — this is the ADVISORY readiness
        # projection, not the full commit gate (triad/scope/custody independent).
        lines: List[str] = ["## Review Continuity", "### Advisory readiness (not the full commit gate)"]
        live_status = str(getattr(current_run, "status", "") or "missing")
        repo_commit_ready = advisory_commit_ready(
            current_run is not None and current_run.status in ("fresh", "bypassed", "skipped"),
            open_obs, open_debts,
            matching_run=current_run if getattr(current_run, "repo_key", None) == repo_key else None,
        )
        lines.append(f"- repo_key={repo_key}")
        lines.append(f"- snapshot_hash={snapshot_hash[:12] or '(empty)'}")
        lines.append(f"- advisory_status={live_status}")
        lines.append(f"- repo_commit_ready={'yes' if repo_commit_ready else 'no'}")
        if current_run is not None:
            lines.append(f"- current_review_ts={str(current_run.ts or '')[:19]}")
            if current_run.bypass_reason:
                lines.append(f"- bypass_reason={_truncate_with_notice(current_run.bypass_reason, 220)}")
        else:
            lines.append("- no advisory run matches the current worktree snapshot")

        stale_matches_repo = not state.last_stale_repo_key or state.last_stale_repo_key == repo_key
        if state.last_stale_from_edit_ts and stale_matches_repo:
            lines.append(
                f"- stale_marker={state.last_stale_from_edit_ts[:19]}: "
                f"{_truncate_with_notice(state.last_stale_reason or 'worktree edit invalidated advisory freshness', 220)}"
            )
            lines.append(f"  invalidated_by={state.stale_marker_attribution_note()}")

        if open_debts:
            lines.append("- retry_anchor=commit_readiness_debt")
            lines.append(f"- commit_readiness_debt={len(open_debts)}")
            lines.append("\n### Commit-readiness debt")
            for debt in open_debts:
                summary = _truncate_with_notice(getattr(debt, "summary", ""), 180).replace("\n", " ")
                lines.append(
                    f"- [{getattr(debt, 'debt_id', '')}] status={getattr(debt, 'status', '')} "
                    f"category={getattr(debt, 'category', '')} source={getattr(debt, 'source', '')}"
                )
                lines.append(f"  summary={summary}")
                if getattr(debt, "source_obligation_ids", None):
                    lines.append(f"  obligation_ids={', '.join(list(debt.source_obligation_ids or []))}")
                for evidence in list(getattr(debt, "evidence", []) or []):
                    lines.append(f"  evidence={_truncate_with_notice(evidence, 180).replace(chr(10), ' ')}")
        else:
            lines.append("- commit_readiness_debt=0")

        if open_obs:
            lines.append(f"- open_obligations={len(open_obs)}")
            for ob in open_obs:
                reason = _truncate_with_notice(getattr(ob, "reason", ""), 120).replace("\n", " ")
                lines.append(
                    f"  [{getattr(ob, 'obligation_id', '')}] "
                    f"{getattr(ob, 'item', '')}: {reason}"
                )
        else:
            lines.append("- open_obligations=0")

        if retired:
            lines.append(f"- {len(retired)} settled continuation(s) archived out of context "
                         "(durable under state/review_continuations/archived/): "
                         + ", ".join(retired[:5])
                         + (f" (+{len(retired) - 5} more)" if len(retired) > 5 else ""))
        scoped_continuations = [
            item for item in continuations
            if item.repo_key in ("", repo_key, _LEGACY_CURRENT_REPO_KEY)
        ]
        if scoped_continuations:
            lines.append("\n### Open review continuations")
            scoped_continuations.sort(key=lambda item: str(item.updated_ts or item.created_ts or ""), reverse=True)
            # Cap review context only with explicit OMISSION NOTEs; no silent slicing.
            _CONTINUATION_CAP = 5
            _PER_FINDING_CAP = 3
            shown_continuations = scoped_continuations[:_CONTINUATION_CAP]
            if len(scoped_continuations) > _CONTINUATION_CAP:
                lines.append(
                    f"⚠️ OMISSION NOTE: {len(scoped_continuations) - _CONTINUATION_CAP} "
                    f"older continuation(s) omitted (showing {_CONTINUATION_CAP} most recent)."
                )
            for item in shown_continuations:
                task_status = str((load_task_result(env.drive_root, item.task_id) or {}).get("status") or "missing")
                lines.append(
                    f"- task={item.task_id} status={task_status} source={item.source} "
                    f"stage={item.stage} tool={item.tool_name or 'commit_reviewed'} "
                    f"attempt={int(item.attempt or 0)}"
                )
                if item.block_reason:
                    lines.append(f"  block_reason={item.block_reason}")
                if item.readiness_warnings:
                    shown = list(item.readiness_warnings)[:_PER_FINDING_CAP]
                    for warn in shown:
                        warning = _truncate_with_notice(warn, 180).replace("\n", " ")
                        lines.append(f"  readiness_warning={warning}")
                    if len(item.readiness_warnings) > _PER_FINDING_CAP:
                        lines.append(
                            f"  ⚠️ OMISSION NOTE: {len(item.readiness_warnings) - _PER_FINDING_CAP} "
                            f"additional readiness_warning(s) omitted."
                        )
                if item.critical_findings:
                    shown = list(item.critical_findings)[:_PER_FINDING_CAP]
                    for top in shown:
                        label = str(top.get("item") or top.get("reason") or "critical finding")
                        reason = _truncate_with_notice(top.get("reason") or "", 140).replace("\n", " ")
                        lines.append(f"  critical_finding={label}: {reason}")
                    if len(item.critical_findings) > _PER_FINDING_CAP:
                        lines.append(
                            f"  ⚠️ OMISSION NOTE: {len(item.critical_findings) - _PER_FINDING_CAP} "
                            f"additional critical_finding(s) omitted."
                        )
                if item.advisory_findings:
                    shown = list(item.advisory_findings)[:_PER_FINDING_CAP]
                    for top in shown:
                        label = str(top.get("item") or top.get("reason") or "advisory finding")
                        reason = _truncate_with_notice(top.get("reason") or "", 140).replace("\n", " ")
                        lines.append(f"  advisory_finding={label}: {reason}")
                    if len(item.advisory_findings) > _PER_FINDING_CAP:
                        lines.append(
                            f"  ⚠️ OMISSION NOTE: {len(item.advisory_findings) - _PER_FINDING_CAP} "
                            f"additional advisory_finding(s) omitted."
                        )
                if item.obligation_ids:
                    lines.append(f"  obligation_ids={', '.join(item.obligation_ids)}")
        if corrupt:
            lines.append("\n### Corrupt review continuations")
            _CORRUPT_CAP = 3
            shown_corrupt = corrupt[:_CORRUPT_CAP]
            for item in shown_corrupt:
                lines.append(f"- {_truncate_with_notice(item, 220)}")
            if len(corrupt) > _CORRUPT_CAP:
                lines.append(
                    f"⚠️ OMISSION NOTE: {len(corrupt) - _CORRUPT_CAP} "
                    f"additional corrupt entry/entries omitted."
                )

        history = format_status_section(state, repo_dir=repo_dir)
        if history:
            history = history.replace("## Advisory Pre-Review Status", "### Historical review ledger")
            lines.append("\n" + history)

        return "\n".join(lines)
    except Exception:
        log.debug("Failed to build review continuity context", exc_info=True)
        return ""

# The v7 post-task-synthesis split: the members below moved into
# ouroboros/post_task_synthesis.py; this facade keeps their historical
# ouroboros.agent_task_pipeline bindings for consumers.
from ouroboros.post_task_synthesis import (  # noqa: E402, F401 -- intentional public re-exports
    build_trace_summary,
    _update_improvement_backlog,
    _apply_reflection_memory_actions,
    _child_task_evidence,
    _pre_synthesis_usage_snapshot,
    _compact_review_projection,
    _record_task_facts,
    _post_task_paid_interruption,
    _run_memory_fallback_draft,
    _run_scratchpad_consolidation,
    _run_reflection,
    finish_published_reflection,
    late_phase_step,
    park_late_phase,
)
