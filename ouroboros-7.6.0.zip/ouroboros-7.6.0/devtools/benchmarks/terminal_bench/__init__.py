"""Terminal-Bench Harbor adapter."""
