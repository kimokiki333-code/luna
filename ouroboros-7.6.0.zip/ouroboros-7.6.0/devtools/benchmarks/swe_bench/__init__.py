"""SWE-bench prediction helpers."""
