"""Shared benchmark helper utilities."""
